ll = [(x, y) for x in [1,2,3] for y in [4,5,6]]
