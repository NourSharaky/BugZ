if True:
    x = 0
elif False:
    y = 0
else:
    z = 0
