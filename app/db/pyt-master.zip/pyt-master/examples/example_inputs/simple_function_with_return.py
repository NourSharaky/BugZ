def foo():
    print('h')
    return 1

def bar():
    x = 2
    return x

y = input()
foo()
x = bar()
