a, *b, c, d, e = f, *g, *h, f + i, j
