def foo():
    return 6

while foo() > x:
    print(x)
    x += 1
