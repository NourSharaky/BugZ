x = input()
y = x - 1
print(x)
