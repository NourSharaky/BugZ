def foo():
    return 6

while x < foo():
    print(x)
    x += 1
