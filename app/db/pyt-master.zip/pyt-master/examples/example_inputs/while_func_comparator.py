def foo():
    return True

while foo():
    print(x)
    x += 1
