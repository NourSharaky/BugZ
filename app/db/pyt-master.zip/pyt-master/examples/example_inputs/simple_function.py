def foo():
    print('h')


y = input()
foo()
