for x in range(3):
    print(x)
    y += 1
x = 3
