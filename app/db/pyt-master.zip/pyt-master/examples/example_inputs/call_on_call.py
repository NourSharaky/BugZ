class String():
    def op(self, b):
        return String()

    def operation(self, a):
        return a

obj = String()
s = obj.op('x').operation('g')
