if True:
    x = 0
else:
    y = 0
