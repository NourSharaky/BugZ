

def my_data(self, foo, bar):
	return redirect(self.something)
