def foo(x):
    z = 1
    x.append(z)

l = [1,2,3]
foo(l)
