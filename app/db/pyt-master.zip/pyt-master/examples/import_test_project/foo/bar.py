def H(s):
    return s + "end"
