def cobia():
    print ("A")
