from .multiple_files import A, B as keens, C as per_se, D as duck_house


a = A.cosme('tlayuda')
b = keens.foo('mutton')
c = per_se.foo('tasting')
d = duck_house.foo('peking')
