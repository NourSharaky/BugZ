import package_with_file_and_alias


package_with_file_and_alias.Eataly.Tea()
