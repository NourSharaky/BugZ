import package_with_file


package_with_file.Starbucks.Tea()
