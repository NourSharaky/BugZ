from foo import bar

bar.H('hey')
