import package_with_folder_and_alias

package_with_folder_and_alias.heyo.moose.fast()
