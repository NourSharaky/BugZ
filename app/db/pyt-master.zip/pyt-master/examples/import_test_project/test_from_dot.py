from . import A


c = A.B('sss')
