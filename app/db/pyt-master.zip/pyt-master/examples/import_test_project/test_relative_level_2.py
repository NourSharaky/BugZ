from ..A import B
import A
b = B('str')
c = A.B('sss')
