import package_with_function


package_with_function.StarbucksVisitor()
