def StarbucksVisitor():
    print ("Iced Mocha")
