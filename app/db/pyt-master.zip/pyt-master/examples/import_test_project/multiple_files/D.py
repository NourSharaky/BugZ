def foo(s):
    return s + "dee"
