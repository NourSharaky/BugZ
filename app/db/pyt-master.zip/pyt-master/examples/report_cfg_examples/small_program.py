x = 3
y = 0
while x > 0:
    print(x)
    x -= 1
    y += x

if y == 5:
    print('five')
else:
    print('close to five')
