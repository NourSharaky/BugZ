`Start here`_.

There is also `some documentation here`_, but it might be less helpful.

.. _Start here: https://github.com/python-security/pyt/tree/master/pyt
.. _some documentation here: http://pyt.readthedocs.io/en/latest/?badge=latest
